﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class BlogComment
    {
        public int CommentId { get; set; }
        public int PostId { get; set; }
        public int AuthorId { get; set; }
        public string Content { get; set; } = null!;
        public DateTime CommentDate { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual Account Author { get; set; } = null!;
        public virtual BlogPost Post { get; set; } = null!;
    }
}
