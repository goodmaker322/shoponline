﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class FeedbackImage
    {
        public int ImageId { get; set; }
        public int? FeedbackId { get; set; }
        public string? ImageUrl { get; set; }

        public virtual Feedback? Feedback { get; set; }
    }
}
