﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class HistoricalContact
    {
        public int Id { get; set; }
        public int? AccountId { get; set; }
        public string? FullName { get; set; }
        public string? Mail { get; set; }
        public string? Mobile { get; set; }
        public bool? Gender { get; set; }

        public virtual Account? Account { get; set; }
    }
}
