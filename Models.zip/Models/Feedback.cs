﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class Feedback
    {
        public Feedback()
        {
            FeedbackImages = new HashSet<FeedbackImage>();
        }

        public int FeedbackId { get; set; }
        public string? Fullname { get; set; }
        public bool? Gender { get; set; }
        public string? Email { get; set; }
        public string? Phone { get; set; }
        public int? UserId { get; set; }
        public int? ProductId { get; set; }
        public int? RateStar { get; set; }
        public DateTime? FeedbackDate { get; set; }
        public string? FeedbackText { get; set; }
        public string? Type { get; set; }

        public virtual Product? Product { get; set; }
        public virtual Account? User { get; set; }
        public virtual ICollection<FeedbackImage> FeedbackImages { get; set; }
    }
}
