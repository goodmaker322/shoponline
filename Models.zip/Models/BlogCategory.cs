﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class BlogCategory
    {
        public BlogCategory()
        {
            BlogPosts = new HashSet<BlogPost>();
        }

        public int CategoryId { get; set; }
        public string? CategoryName { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual ICollection<BlogPost> BlogPosts { get; set; }
    }
}
