﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class Order
    {
        public Order()
        {
            OrderDetails = new HashSet<OrderDetail>();
        }

        public int OrderId { get; set; }
        public int CustomerId { get; set; }
        public string Address { get; set; } = null!;
        public DateTime? CreateDate { get; set; }
        public DateTime? ShippingDate { get; set; }
        public DateTime? RequiredDate { get; set; }
        public int? Status { get; set; }
        public int? PaymentId { get; set; }
        public int? CouponId { get; set; }
        public bool? IsDeleted { get; set; }
        public double? TotalPrice { get; set; }
        public int? SaleId { get; set; }

        public virtual Coupon? Coupon { get; set; }
        public virtual Account Customer { get; set; } = null!;
        public virtual Payment? Payment { get; set; }
        public virtual ICollection<OrderDetail> OrderDetails { get; set; }
    }
}
