﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class CartItem
    {
        public int CartId { get; set; }
        public int ProductId { get; set; }
        public int Quantity { get; set; }
        public bool? IsDeleted { get; set; }
        public double Price { get; set; }
        public double? Total { get; set; }
        public int UserId { get; set; }
        public string ProductDescription { get; set; }


        //order --> hàm dc khởi tạo item, ko có thì đem gtri null
        public CartItem()
        {


        }

        // so sánh id sản phẩm add và sản phẩm lấy ra rừ db
        public CartItem(Product product)
        {
            ProductId = product.ProductId;
            Product = product;


            if (Product.SalePrice == null)
            {
                Price = product.Price;
            }
            else
            {
                Price = product.SalePrice.Value;
            }
            ProductDescription = product.Description;

            Quantity = 1;


        }

        public virtual Product Product { get; set; } = null!;
        public virtual Account User { get; set; } = null!;
    }
}
