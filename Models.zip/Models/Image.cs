﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class Image
    {
        public Image()
        {
            Products = new HashSet<Product>();
        }

        public int ImageId { get; set; }
        public string? ImageLink { get; set; }
        public DateTime? CreateDate { get; set; }
        public bool? IsDeleted { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}
