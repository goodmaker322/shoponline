﻿namespace OnlineShop_G1.Models.ViewModels
{
    public class PostViewModel
    {
        public string Title { get; set; }
        public string Content { get; set; }
        public string CategoryName { get; set; }
        public string AuthorName { get; set; }
        public DateTime? PublishDate { get; set; }
        public string PostImage { get; set; }
        public string Status { get; set; }
    }

}
