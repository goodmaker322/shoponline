﻿namespace OnlineShop_G1.Models.ViewModels
{
	public class CartItemViewModel
	{

		//da anh xa du lieu cua Orderdetail da co all truong can thiet
		public List<OrderDetail> Items { get; set; }

		public double GrandTotal { get; set; }
	}
}
