﻿using OnlineShop_G1.Models.ViewModels;
using System;
using System.Collections.Generic;
using System.Linq;

namespace OnlineShop_G1.Models
{
    public class OrderViewModel
    {
        public int OrderId { get; set; }
        public DateTime CreateDate { get; set; }
        public DateTime? ShippingDate { get; set; } // Nullable
        public DateTime? RequiredDate { get; set; } // Nullable
        public int Status { get; set; }
        public string StatusDescription
        {
            get
            {
                return Status switch
                {
                    1 => "Submitted",
                    2 => "Order successful",
                    3 => "Cancelled",
                    _ => "Unknown status" // Default case to handle unexpected values
                };
            }
        }
        public List<OrderDetailViewModel> OrderDetails { get; set; }
        public string RecipientFullName { get; set; }
        public bool? RecipientGender { get; set; }
        public string RecipientEmail { get; set; }
        public string RecipientPhone { get; set; }

        // Calculate TotalPrice in the ViewModel
        public decimal TotalPrice
        {
            get
            {
                return OrderDetails.Sum(od => od.Quantity * od.Price);
            }
        }

        // Add Coupon information if necessary
        public string CouponCode { get; set; }
        public int? DiscountPercent { get; set; }

        // Add PaymentId and CouponId fields
        public int? PaymentId { get; set; } // Nullable
        public int? CouponId { get; set; } // Nullable
    }
}