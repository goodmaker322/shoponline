﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class BlogPost
    {
        public BlogPost()
        {
            BlogComments = new HashSet<BlogComment>();
        }

        public int PostId { get; set; }
        public string Content { get; set; } = null!;
        public int AuthorId { get; set; }
        public int CategoryId { get; set; }
        public DateTime? PublishDate { get; set; }
        public bool? IsDeleted { get; set; }
        public string? PostImage { get; set; }
        public string? Title { get; set; }
        public bool? Featured { get; set; }

        public virtual Account Author { get; set; } = null!;
        public virtual BlogCategory Category { get; set; } = null!;
        public virtual ICollection<BlogComment> BlogComments { get; set; }
    }
}
