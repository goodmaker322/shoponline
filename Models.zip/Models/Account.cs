﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class Account
    {
        public Account()
        {
            BlogComments = new HashSet<BlogComment>();
            BlogPosts = new HashSet<BlogPost>();
            CartItems = new HashSet<CartItem>();
            Feedbacks = new HashSet<Feedback>();
            HistoricalContacts = new HashSet<HistoricalContact>();
            Orders = new HashSet<Order>();
            Products = new HashSet<Product>();
            Reviews = new HashSet<Review>();
        }

        public int AccountId { get; set; }
        public string FullName { get; set; } = null!;
        public string Mail { get; set; } = null!;
        public string Address { get; set; } = null!;
        public DateTime? Dob { get; set; }
        public bool? Gender { get; set; }
        public string? Phone { get; set; }
        public string? Password { get; set; }
        public bool Active { get; set; }
        public int RoleId { get; set; }
        public bool? IsDeleted { get; set; }
        public bool? GmailValidated { get; set; }
        public string? Avatar { get; set; }

        public virtual Role Role { get; set; } = null!;
        public virtual ICollection<BlogComment> BlogComments { get; set; }
        public virtual ICollection<BlogPost> BlogPosts { get; set; }
        public virtual ICollection<CartItem> CartItems { get; set; }
        public virtual ICollection<Feedback> Feedbacks { get; set; }
        public virtual ICollection<HistoricalContact> HistoricalContacts { get; set; }
        public virtual ICollection<Order> Orders { get; set; }
        public virtual ICollection<Product> Products { get; set; }
        public virtual ICollection<Review> Reviews { get; set; }
    }
}
