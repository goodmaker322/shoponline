﻿using System;
using System.Collections.Generic;

namespace OnlineShop_G1.Models
{
    public partial class DetailProduct
    {
        public DetailProduct()
        {
            Products = new HashSet<Product>();
        }

        public int DetailId { get; set; }
        public string? Screen { get; set; }
        public string? OperatingSystem { get; set; }
        public string? FearCamera { get; set; }
        public string? FrontCamera { get; set; }
        public string? Chips { get; set; }
        public string? StorageCapacity { get; set; }
        public string? RechargeableBatteries { get; set; }

        public virtual ICollection<Product> Products { get; set; }
    }
}
